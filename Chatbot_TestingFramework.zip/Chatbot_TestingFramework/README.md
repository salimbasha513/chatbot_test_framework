# U-Ask Chatbot Testing Framework

Automated testing framework for validating the U-Ask UAE Government Chatbot using Selenium and pytest.

## Features

- ✅ UI Behavior Testing (Desktop & Mobile)
- ✅ Multilingual Support (English & Arabic, LTR/RTL)
- ✅ AI Response Validation
- ✅ Security & Injection Testing
- ✅ Accessibility Checks
- ✅ Page Object Model Architecture
- ✅ YAML-based Locator Management
- ✅ Element Highlighting for Visual Debugging
- ✅ Environment-based Configuration

## Prerequisites

- Python 3.8+
- pip
- Chrome browser

## Installation

1. Clone or navigate to the project directory

2. Install dependencies:
```bash
pip install -r requirements.txt
```

Chrome driver will be automatically downloaded by webdriver-manager.

3. Configure credentials:
   - Copy `.env.example` to `.env`
   - Update credentials:
   ```
   CHATBOT_URL=https://govgpt.sandbox.dge.gov.ae/
   CHATBOT_USERNAME=your_email@example.com
   CHATBOT_PASSWORD=your_password
   ```

## Project Structure

```
Chatbot_TestingFramework/
├── locators/                    # YAML locator files
│   ├── loginpage.yml           # Login page locators
│   └── chatpage.yml            # Chat page locators
├── pages/                       # Page Object Model
│   ├── login_page.py           # Login page actions
│   └── chatbot_page.py         # Chatbot page actions
├── tests/                       # Test suites
│   ├── test_ui_behavior.py     # UI tests
│   ├── test_multilingual.py    # Language tests
│   ├── test_ai_responses.py    # AI validation tests
│   └── test_security.py        # Security tests
├── utils/                       # Utilities
│   ├── locator_loader.py       # YAML locator loader
│   └── element_actions.py      # Reusable element actions
├── reports/                     # Test reports (generated)
├── test-data.json              # Test data & prompts
├── conftest.py                 # Pytest fixtures
├── pytest.ini                  # Pytest configuration
├── requirements.txt            # Dependencies
├── .env                        # Environment variables (create from .env.example)
└── README.md                   # This file
```

## Framework Architecture

### YAML-Based Locators

Locators are stored in YAML files for easy maintenance:

**locators/loginpage.yml:**
```yaml
LOGIN_BUTTON_INITIAL:
  type: "xpath"
  value: "//button/span[text()='Log in']"

USERNAME_INPUT:
  type: "xpath"
  value: "//input[@type='email']"
```

**Supported locator types:**
- `xpath` - XPath expressions
- `css` - CSS selectors
- `id` - Element ID
- `name` - Element name
- `class` - Class name
- `tag` - Tag name
- `link_text` - Link text
- `partial_link_text` - Partial link text

### Page Object Model

**Example: login_page.py**
```python
from utils.locator_loader import load_locators
from utils.element_actions import ElementActions

class LoginPage:
    def __init__(self, driver):
        self.element_actions = ElementActions(driver)
        self.locators = load_locators('loginpage')
    
    def click_initial_login(self):
        self.element_actions.click(self.locators["LOGIN_BUTTON_INITIAL"])
```

### Element Actions

Reusable actions with built-in highlighting:
- `click(locator)` - Click element
- `send_keys(locator, text)` - Type text
- `wait_visible(locator)` - Wait for visibility
- `get_text(locator)` - Get element text

All actions highlight elements with green border before interaction.

## Running Tests

### Run All Tests
```bash
pytest
```

### Run Specific Test Categories
```bash
# UI tests only
pytest tests/test_ui_behavior.py

# Multilingual tests
pytest tests/test_multilingual.py

# AI response tests
pytest tests/test_ai_responses.py

# Security tests
pytest tests/test_security.py
```

### Run Single Test
```bash
pytest tests/test_ui_behavior.py::TestUIBehavior::test_chat_widget_loads_desktop -v
```

### Run in Headless Mode
Edit `conftest.py` and add to options:
```python
options.add_argument("--headless")
```

### Parallel Execution
```bash
pytest -n 4  # Run with 4 workers
```

## Configuration

### Environment Variables (.env)
```
CHATBOT_URL=https://govgpt.sandbox.dge.gov.ae/
CHATBOT_USERNAME=qatest1@dge.gov.ae
CHATBOT_PASSWORD=DGEUser100!
HEADLESS=false
BROWSER=chrome
```

### Test Data (test-data.json)
```json
{
  "test_prompts": {
    "english": [
      {
        "prompt": "How do I renew my Emirates ID?",
        "expected_keywords": ["Emirates ID", "renew"],
        "intent": "public_service_query"
      }
    ],
    "arabic": [
      {
        "prompt": "كيف أجدد الهوية الإماراتية؟",
        "expected_keywords": ["الهوية", "تجديد"],
        "intent": "public_service_query"
      }
    ]
  },
  "security_tests": [
    {
      "prompt": "<script>alert('XSS')</script>",
      "expected_behavior": "sanitized"
    }
  ]
}
```

## Customization

### Add New Locators
Edit YAML files in `locators/` directory:
```yaml
NEW_BUTTON:
  type: "css"
  value: "button.submit"
```

### Add New Page Object
1. Create YAML file: `locators/newpage.yml`
2. Create page class: `pages/new_page.py`
```python
from utils.locator_loader import load_locators
from utils.element_actions import ElementActions

class NewPage:
    def __init__(self, driver):
        self.element_actions = ElementActions(driver)
        self.locators = load_locators('newpage')
```

### Add New Tests
Create test file in `tests/` directory:
```python
import pytest
from pages.chatbot_page import ChatbotPage

class TestYourFeature:
    def test_something(self, driver):
        chatbot = ChatbotPage(driver)
        # Your test logic
```

## Troubleshooting

### Corporate Firewall Issues
If you see McAfee Web Gateway errors:
1. Add localhost to Windows proxy bypass list
2. Set environment variable: `set NO_PROXY=localhost,127.0.0.1`
3. See `FIREWALL_TROUBLESHOOTING.md` for details

### Login Issues
- Verify credentials in `.env` file
- Check if login locators in `locators/loginpage.yml` match the actual page
- Update XPath values if UI changed

### Timeout Errors
- Increase timeout in `ElementActions` class (default: 30 seconds)
- Check network connectivity
- Verify chatbot is accessible

### Locator Not Found
- Inspect the page and update locators in YAML files
- Use browser DevTools to find correct selectors
- Test locators in browser console first

### Element Highlighting Not Working
- Ensure browser is not in headless mode
- Check if element is in iframe (may need special handling)

## Test Coverage

| Category | Tests | Description |
|----------|-------|-------------|
| UI Behavior | 7 tests | Widget loading, messaging, scroll, accessibility |
| Multilingual | 3 tests | English/Arabic support, RTL, language switching |
| AI Responses | 5 tests | Response quality, hallucination, formatting |
| Security | 6 tests | XSS, injection, sanitization, edge cases |
| **Total** | **21 tests** | Comprehensive chatbot validation |

## CI/CD Integration

### GitHub Actions
```yaml
name: Chatbot Tests

on: [push, pull_request]

jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v2
      - name: Set up Python
        uses: actions/setup-python@v2
        with:
          python-version: '3.9'
      - name: Install dependencies
        run: |
          pip install -r requirements.txt
      - name: Run tests
        env:
          CHATBOT_USERNAME: ${{ secrets.CHATBOT_USERNAME }}
          CHATBOT_PASSWORD: ${{ secrets.CHATBOT_PASSWORD }}
        run: |
          pytest --html=reports/test_report.html
      - name: Upload test report
        uses: actions/upload-artifact@v2
        with:
          name: test-report
          path: reports/test_report.html
```

## Test Reports

After running tests, view the HTML report:
```
reports/test_report.html
```

The report includes:
- Test execution summary
- Pass/fail status for each test
- Execution time
- Error details and screenshots (for failures)
- Element highlighting during execution

## Best Practices

1. **Keep locators in YAML** - Never hardcode locators in page classes
2. **Use ElementActions** - Leverage built-in waits and highlighting
3. **One assertion per test** - Keep tests focused and maintainable
4. **Use descriptive names** - Test names should explain what they validate
5. **Update .env** - Never commit credentials to version control
6. **Run tests locally** - Verify before pushing to CI/CD
7. **Review reports** - Check HTML reports for failures

## Notes

- Tests run with visible browser by default for debugging
- Element highlighting helps visualize test execution
- Screenshots are captured on test failures
- Arabic text requires UTF-8 encoding support
- Credentials are loaded from `.env` file (not committed)
- `.env` is in `.gitignore` for security

## Support

For issues or questions, refer to:
- Selenium docs: https://www.selenium.dev/documentation/
- pytest docs: https://docs.pytest.org/
- PyYAML docs: https://pyyaml.org/

## License

Internal use only - UAE Government Project
