import pytest
import json
import os
from dotenv import load_dotenv
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.support.ui import WebDriverWait
from webdriver_manager.chrome import ChromeDriverManager
from pages.login_page import LoginPage

load_dotenv()

@pytest.fixture(scope="session")
def test_data():
    with open("test-data.json", "r", encoding="utf-8") as f:
        data = json.load(f)
    
    # Override with environment variables if present
    data["credentials"]["url"] = os.getenv("CHATBOT_URL", data["credentials"]["url"])
    data["credentials"]["username"] = os.getenv("CHATBOT_USERNAME", data["credentials"]["username"])
    data["credentials"]["password"] = os.getenv("CHATBOT_PASSWORD", data["credentials"]["password"])
    
    return data

@pytest.fixture(scope="function")
def driver(test_data):
    options = Options()
    options.add_argument("--start-maximized")
    options.add_argument("--disable-blink-features=AutomationControlled")
    options.add_argument("--proxy-bypass-list=localhost,127.0.0.1")
    options.add_argument("--no-proxy-server")
    
    driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()), options=options)
    driver.implicitly_wait(10)
    
    driver.get(test_data["credentials"]["url"])
    
    try:
        login_page = LoginPage(driver)
        login_page.login(test_data["credentials"]["username"], test_data["credentials"]["password"])
        WebDriverWait(driver, 10).until(lambda d: d.current_url != test_data["credentials"]["url"])
    except:
        pass
    
    yield driver
    driver.quit()

@pytest.fixture(scope="function")
def mobile_driver(test_data):
    options = Options()
    options.add_argument("--disable-blink-features=AutomationControlled")
    options.add_argument("--proxy-bypass-list=localhost,127.0.0.1")
    options.add_argument("--no-proxy-server")
    mobile_emulation = {"deviceName": "iPhone 12 Pro"}
    options.add_experimental_option("mobileEmulation", mobile_emulation)
    
    driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()), options=options)
    driver.implicitly_wait(10)
    
    driver.get(test_data["credentials"]["url"])
    
    try:
        login_page = LoginPage(driver)
        login_page.login(test_data["credentials"]["username"], test_data["credentials"]["password"])
        WebDriverWait(driver, 10).until(lambda d: d.current_url != test_data["credentials"]["url"])
    except:
        pass
    
    yield driver
    driver.quit()

def pytest_html_report_title(report):
    report.title = "U-Ask Chatbot Test Report"
