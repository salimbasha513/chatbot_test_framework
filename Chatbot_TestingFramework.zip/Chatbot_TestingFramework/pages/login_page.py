from utils.locator_loader import load_locators
from utils.element_actions import ElementActions

class LoginPage:
    def __init__(self, driver):
        self.driver = driver
        self.element_actions = ElementActions(driver)
        self.locators = load_locators('loginpage')
    
    def click_initial_login(self):
        self.element_actions.wait_visible(self.locators["TITLE"])
        self.element_actions.click(self.locators["LOGIN_BUTTON_INITIAL"])
    
    def enter_username(self, username):
        self.element_actions.send_keys(self.locators["USERNAME_INPUT"], username)
    
    def enter_password(self, password):
        self.element_actions.send_keys(self.locators["PASSWORD_INPUT"], password)
    
    def click_login_submit(self):
        self.element_actions.click(self.locators["LOGIN_BUTTON_SUBMIT"])
    
    def login(self, username, password):
        self.click_initial_login()
        self.enter_username(username)
        self.enter_password(password)
        self.click_login_submit()
