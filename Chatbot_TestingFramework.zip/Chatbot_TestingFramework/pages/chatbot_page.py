from utils.locator_loader import load_locators
from utils.element_actions import ElementActions
import time

class ChatbotPage:
    def __init__(self, driver):
        self.driver = driver
        self.element_actions = ElementActions(driver)
        self.locators = load_locators('chatpage')
    
    def get_chat_widget(self):
        return self.element_actions.find_elements(self.locators["CHAT_WIDGET"])
    
    def get_input_box(self):
        elements = self.element_actions.find_elements(self.locators["INPUT_BOX"])
        return elements[-1] if elements else None
    
    def get_send_button(self):
        elements = self.element_actions.find_elements(self.locators["SEND_BUTTON"])
        return elements[-1] if elements else None
    
    def get_messages(self):
        return self.element_actions.find_elements(self.locators["MESSAGES"])
    
    def get_loading_indicator(self):
        return self.element_actions.find_elements(self.locators["LOADING_INDICATOR"])
    
    def wait_for_chat_widget(self, timeout=10):
        self.element_actions.wait_visible(self.locators["CHAT_WIDGET"])
    
    def send_message(self, message: str):
        input_box = self.get_input_box()
        input_box.clear()
        input_box.send_keys(message)
        initial_count = len(self.get_messages())
        
        send_button = self.get_send_button()
        send_button.click()
        
        time.sleep(2)
        from selenium.webdriver.support.ui import WebDriverWait
        WebDriverWait(self.driver, 30).until(lambda d: len(self.get_messages()) > initial_count)
    
    def get_last_response(self):
        time.sleep(1)
        messages = self.get_messages()
        if len(messages) > 0:
            return messages[-1].text
        return ""
    
    def wait_for_response(self, timeout=30):
        try:
            loading = self.get_loading_indicator()
            if loading:
                from selenium.webdriver.support.ui import WebDriverWait
                from selenium.webdriver.support import expected_conditions as EC
                WebDriverWait(self.driver, timeout).until(
                    EC.invisibility_of_element_located(self.locators["LOADING_INDICATOR"])
                )
        except:
            pass
        time.sleep(2)
    
    def is_input_cleared(self):
        input_box = self.get_input_box()
        return input_box.get_attribute("value") == "" or input_box.text == ""
    
    def get_text_direction(self):
        from selenium.webdriver.common.by import By
        return self.driver.find_element(By.TAG_NAME, "html").get_attribute("dir") or "ltr"
    
    def check_rtl_support(self):
        from selenium.webdriver.common.by import By
        return len(self.driver.find_elements(By.CSS_SELECTOR, "[dir='rtl'], [style*='rtl']")) > 0
    
    def is_scrollable(self):
        return self.driver.execute_script("""
            const el = document.querySelector('[class*="message"], [class*="chat"]');
            return el ? el.scrollHeight > el.clientHeight : false;
        """)
    
    def check_accessibility(self):
        from selenium.webdriver.common.by import By
        input_box = self.get_input_box()
        return {
            "has_aria_labels": len(self.driver.find_elements(By.CSS_SELECTOR, "[aria-label]")) > 0,
            "has_alt_text": len(self.driver.find_elements(By.CSS_SELECTOR, "img[alt]")) == len(self.driver.find_elements(By.TAG_NAME, "img")),
            "keyboard_navigable": input_box.is_enabled() if input_box else False
        }
    
    def get_response_html(self):
        messages = self.get_messages()
        if len(messages) > 0:
            return messages[-1].get_attribute("innerHTML")
        return ""
    
    def check_for_script_tags(self):
        from selenium.webdriver.common.by import By
        return len(self.driver.find_elements(By.CSS_SELECTOR, "script:not([src])"))
