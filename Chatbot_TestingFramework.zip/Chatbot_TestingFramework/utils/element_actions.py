from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import time

class ElementActions:
    def __init__(self, driver, timeout=30):
        self.driver = driver
        self.wait = WebDriverWait(driver, timeout)
    
    def highlight_element(self, element):
        """Highlights (blinks) a Selenium Webdriver element"""
        driver = element._parent

        def apply_style(s):
            driver.execute_script(f"arguments[0].style.border='{s}'", element)
        original_style = driver.execute_script("return arguments[0].style.border;", element)
        apply_style("3px solid green")
        time.sleep(0.5)
        apply_style(original_style)
    
    def click(self, locator):
        element = self.wait.until(EC.element_to_be_clickable(locator))
        self.highlight_element(element)
        element.click()
    
    def send_keys(self, locator, text):
        element = self.wait.until(EC.presence_of_element_located(locator))
        self.highlight_element(element)
        element.send_keys(text)
    
    def wait_visible(self, locator):
        element = self.wait.until(EC.visibility_of_element_located(locator))
        self.highlight_element(element)
    
    def get_text(self, locator):
        element = self.wait.until(EC.presence_of_element_located(locator))
        self.highlight_element(element)
        return element.text
    
    def find_element(self, locator):
        return self.driver.find_element(*locator)
    
    def find_elements(self, locator):
        return self.driver.find_elements(*locator)
