import yaml
from pathlib import Path
from selenium.webdriver.common.by import By

LOCATORS_DIR = Path(__file__).parent.parent / "locators"

def load_locators(page_name: str):
    file = LOCATORS_DIR / f"{page_name}.yml"
    raw = yaml.safe_load(file.read_text())
    mapping = {
        "id": By.ID,
        "xpath": By.XPATH,
        "css": By.CSS_SELECTOR,
        "class": By.CLASS_NAME,
        "name": By.NAME,
        "link_text": By.LINK_TEXT,
        "partial_link_text": By.PARTIAL_LINK_TEXT,
        "tag": By.TAG_NAME,
    }
    return {k: (mapping[v["type"]], v["value"]) for k, v in raw.items()}
