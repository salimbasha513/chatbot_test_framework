import pytest
from pages.chatbot_page import ChatbotPage

class TestAIResponses:
    
    @pytest.mark.parametrize("lang", ["english", "arabic"])
    def test_response_contains_keywords(self, driver, test_data, lang):
        chatbot = ChatbotPage(driver)
        chatbot.wait_for_chat_widget()
        
        prompts = test_data["test_prompts"][lang]
        for prompt_data in prompts[:2]:
            chatbot.send_message(prompt_data["prompt"])
            chatbot.wait_for_response()
            
            response = chatbot.get_last_response().lower()
            assert len(response) > 10, f"Response too short for: {prompt_data['prompt']}"
    
    def test_no_hallucination_check(self, driver):
        chatbot = ChatbotPage(driver)
        chatbot.wait_for_chat_widget()
        
        chatbot.send_message("What is the capital of UAE?")
        chatbot.wait_for_response()
        
        response = chatbot.get_last_response().lower()
        assert "abu dhabi" in response or "أبوظبي" in response, "Incorrect factual response"
    
    def test_response_formatting(self, driver, test_data):
        chatbot = ChatbotPage(driver)
        chatbot.wait_for_chat_widget()
        
        chatbot.send_message(test_data["test_prompts"]["english"][0]["prompt"])
        chatbot.wait_for_response()
        
        html = chatbot.get_response_html()
        
        assert "<script>" not in html.lower(), "Script tags in response"
        assert "undefined" not in html.lower(), "Undefined in response"
        assert html.count("<") == html.count(">"), "Unbalanced HTML tags"
    
    def test_loading_state_appears(self, driver):
        chatbot = ChatbotPage(driver)
        chatbot.wait_for_chat_widget()
        
        input_box = chatbot.get_input_box()
        input_box.send_keys("Test message")
        chatbot.get_send_button().click()
        
        import time
        time.sleep(0.5)
        chatbot.wait_for_response()
        assert len(chatbot.get_last_response()) > 0
    
    def test_consistency_similar_intent(self, driver, test_data):
        chatbot = ChatbotPage(driver)
        chatbot.wait_for_chat_widget()
        
        question = test_data["test_prompts"]["english"][0]["prompt"]
        
        chatbot.send_message(question)
        chatbot.wait_for_response()
        response1 = chatbot.get_last_response()
        
        chatbot.send_message(question)
        chatbot.wait_for_response()
        response2 = chatbot.get_last_response()
        
        assert len(response1) > 0 and len(response2) > 0
        words1 = set(response1.lower().split())
        words2 = set(response2.lower().split())
        common = words1.intersection(words2)
        assert len(common) > 3, "Responses too different for same question"
