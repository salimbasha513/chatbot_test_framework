import pytest
from pages.chatbot_page import ChatbotPage

class TestMultilingual:
    
    def test_english_ltr_support(self, driver, test_data):
        chatbot = ChatbotPage(driver)
        chatbot.wait_for_chat_widget()
        
        english_prompt = test_data["test_prompts"]["english"][0]["prompt"]
        chatbot.send_message(english_prompt)
        chatbot.wait_for_response()
        
        response = chatbot.get_last_response()
        assert len(response) > 0, "No response for English prompt"
    
    def test_arabic_rtl_support(self, driver, test_data):
        chatbot = ChatbotPage(driver)
        chatbot.wait_for_chat_widget()
        
        arabic_prompt = test_data["test_prompts"]["arabic"][0]["prompt"]
        chatbot.send_message(arabic_prompt)
        chatbot.wait_for_response()
        
        response = chatbot.get_last_response()
        assert len(response) > 0, "No response for Arabic prompt"
    
    def test_language_switching(self, driver, test_data):
        chatbot = ChatbotPage(driver)
        chatbot.wait_for_chat_widget()
        
        chatbot.send_message(test_data["test_prompts"]["english"][0]["prompt"])
        chatbot.wait_for_response()
        english_response = chatbot.get_last_response()
        
        chatbot.send_message(test_data["test_prompts"]["arabic"][0]["prompt"])
        chatbot.wait_for_response()
        arabic_response = chatbot.get_last_response()
        
        assert len(english_response) > 0 and len(arabic_response) > 0
