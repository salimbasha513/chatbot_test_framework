import pytest
from pages.chatbot_page import ChatbotPage

class TestSecurity:
    
    def test_xss_script_tag_sanitized(self, driver, test_data):
        chatbot = ChatbotPage(driver)
        chatbot.wait_for_chat_widget()
        
        xss_payload = test_data["security_tests"][0]["prompt"]
        chatbot.send_message(xss_payload)
        chatbot.wait_for_response()
        
        script_count = chatbot.check_for_script_tags()
        response_html = chatbot.get_response_html()
        
        assert "<script>" not in response_html, "Script tag not sanitized"
        assert "alert" not in response_html or "&lt;script&gt;" in response_html, "XSS not prevented"
    
    def test_prompt_injection_resistance(self, driver, test_data):
        chatbot = ChatbotPage(driver)
        chatbot.wait_for_chat_widget()
        
        injection = test_data["security_tests"][1]["prompt"]
        chatbot.send_message(injection)
        chatbot.wait_for_response()
        
        response = chatbot.get_last_response().lower()
        assert len(response) > 0, "No response to injection attempt"
    
    def test_html_injection_sanitized(self, driver, test_data):
        chatbot = ChatbotPage(driver)
        chatbot.wait_for_chat_widget()
        
        html_payload = test_data["security_tests"][2]["prompt"]
        chatbot.send_message(html_payload)
        chatbot.wait_for_response()
        
        response_html = chatbot.get_response_html()
        assert "<img" not in response_html or "onerror" not in response_html, "HTML injection not sanitized"
    
    def test_special_characters_handled(self, driver):
        chatbot = ChatbotPage(driver)
        chatbot.wait_for_chat_widget()
        
        special_chars = "!@#$%^&*()_+-=[]{}|;:',.<>?/~`"
        chatbot.send_message(special_chars)
        chatbot.wait_for_response()
        
        response = chatbot.get_last_response()
        assert len(response) > 0, "Failed to handle special characters"
    
    def test_empty_input_handling(self, driver, test_data):
        chatbot = ChatbotPage(driver)
        chatbot.wait_for_chat_widget()
        
        initial_count = len(chatbot.get_messages())
        input_box = chatbot.get_input_box()
        input_box.clear()
        
        send_button = chatbot.get_send_button()
        if send_button.is_enabled():
            send_button.click()
            import time
            time.sleep(2)
            assert len(chatbot.get_messages()) == initial_count or len(chatbot.get_messages()) == initial_count + 1
    
    def test_long_input_handling(self, driver, test_data):
        chatbot = ChatbotPage(driver)
        chatbot.wait_for_chat_widget()
        
        long_input = test_data["edge_cases"][1]["prompt"]
        chatbot.send_message(long_input)
        chatbot.wait_for_response()
        
        response = chatbot.get_last_response()
        assert len(response) > 0, "Failed to handle long input"
