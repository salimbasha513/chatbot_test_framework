import pytest
from pages.chatbot_page import ChatbotPage

class TestUIBehavior:
    
    def test_chat_widget_loads_desktop(self, driver):
        chatbot = ChatbotPage(driver)
        chatbot.wait_for_chat_widget()
        assert len(chatbot.get_chat_widget()) > 0 or chatbot.get_input_box() is not None
    
    def test_chat_widget_loads_mobile(self, mobile_driver):
        chatbot = ChatbotPage(mobile_driver)
        chatbot.wait_for_chat_widget()
        assert len(chatbot.get_chat_widget()) > 0 or chatbot.get_input_box() is not None
    
    def test_user_can_send_message(self, driver):
        chatbot = ChatbotPage(driver)
        chatbot.wait_for_chat_widget()
        
        test_message = "Hello"
        chatbot.send_message(test_message)
        chatbot.wait_for_response()
        
        response = chatbot.get_last_response()
        assert len(response) > 0, "No response received"
    
    def test_input_cleared_after_sending(self, driver):
        chatbot = ChatbotPage(driver)
        chatbot.wait_for_chat_widget()
        
        chatbot.send_message("Test message")
        assert chatbot.is_input_cleared(), "Input not cleared after sending"
    
    def test_messages_rendered_properly(self, driver):
        chatbot = ChatbotPage(driver)
        chatbot.wait_for_chat_widget()
        
        chatbot.send_message("Test")
        chatbot.wait_for_response()
        
        assert len(chatbot.get_messages()) > 0, "Messages not rendered"
    
    def test_scroll_functionality(self, driver):
        chatbot = ChatbotPage(driver)
        chatbot.wait_for_chat_widget()
        
        for i in range(5):
            chatbot.send_message(f"Message {i}")
            chatbot.wait_for_response()
        
        assert len(chatbot.get_messages()) >= 5
    
